// function roundNumber(number) {
//     var newString; // The new rounded number
//     decimals = Number(decimals);
//     if (decimals < 1) {
//         newString = (Math.round(number)).toString();
//     } else {
//         var numString = number.toString();
//         if (numString.lastIndexOf(".") == -1) { // If there is no decimal point
//             numString += "."; // give it one at the end
//         }
//         var cutoff = numString.lastIndexOf(".") + decimals; // The point at which to truncate the number
//         var d1 = Number(numString.substring(cutoff, cutoff + 1)); // The value of the last decimal place that we'll end up with
//         var d2 = Number(numString.substring(cutoff + 1, cutoff + 2)); // The next decimal, after the last one we want
//         if (d2 >= 5) { // Do we need to round up at all? If not, the string will just be truncated
//             if (d1 == 9 && cutoff > 0) { // If the last digit is 9, find a new cutoff point
//                 while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
//                     if (d1 != ".") {
//                         cutoff -= 1;
//                         d1 = Number(numString.substring(cutoff, cutoff + 1));
//                     } else {
//                         cutoff -= 1;
//                     }
//                 }
//             }
//             d1 += 1;
//         }
//         if (d1 == 10) {
//             numString = numString.substring(0, numString.lastIndexOf("."));
//             var roundedNum = Number(numString) + 1;
//             newString = roundedNum.toString() + '.';
//         } else {
//             newString = numString.substring(0, cutoff) + d1.toString();
//         }
//     }
//     if (newString.lastIndexOf(".") == -1) { // Do this again, to the new string
//         newString += "";
//     }
//     var decs = (newString.substring(newString.lastIndexOf(".") + 1)).length;
//     for (var i = 0; i < decimals - decs; i++) newString += "0";
//     //var newNumber = Number(newString);// make it a number if you like
//     return newString; // Output the result to the form field (change for your purposes)
// }

function update_total() {
    var total = 0;
    $('.price').each(function(i) {
        price = $(this).html().replace("", "");
        if (!isNaN(price)) total += Number(price);
    });


    //total = roundNumber(total, 0);

    $('#subtotal').html(total);


    var subtotal = document.getElementById("subtotal").innerHTML;
    var discount = document.getElementById("discount").value;

    var discounted_value =  Math.round((subtotal * discount)/100);
    document.getElementById("discounted_value").innerHTML = discounted_value;

    var packingchargespercentage = document.getElementById("packingcharge").value;
    var packingcharges = Math.round((subtotal * packingchargespercentage)/100);
    document.getElementById("packingandforwarding").innerHTML = packingcharges;

    var accessable_value = Number(subtotal )+ Number (packingcharges) - Number(discounted_value);

    document.getElementById("accessablevalue").innerHTML = accessable_value;

    var cgst_value = document.getElementById("central_gst").value;

    var sgst_value = document.getElementById("state_gst").value;

    var cgst = Math.round((accessable_value * cgst_value)/100);
    document.getElementById("centralgst").innerHTML = cgst;

    var sgst = Math.round((accessable_value * sgst_value)/100);
    document.getElementById("stategst").innerHTML = sgst;

    var igst_value = document.getElementById("integrated_gst").value;
    var igst = Math.round((accessable_value * igst_value)/100);
    document.getElementById("igst").innerHTML =igst;


    var total = accessable_value + cgst + sgst + igst ;

    document.getElementById("total").innerHTML = total;
}



function update_price() {
    var row = $(this).parents('.item-row');
    var price = row.find('.cost').val().replace("", "") * row.find('.qty').val();
    //price = roundNumber(price, 1);
    isNaN(price) ? row.find('.price').html("N/A") : row.find('.price').html(price);

    update_total();
}

function bind() {
    $(".cost").blur(update_price);
    $(".qty").blur(update_price);
}

$(document).ready(function() {

    $('input').click(function() {
        $(this).select();
    });


    $("#addrow").click(function() {
        rowIndex++;
        console.log(rowIndex);
        slno++;
        $(".item-row:last").after('<tr class="item-row" id= "item-row'+slno+'"><td class="text-center">'+slno+'</td><td class="item-name" colspan="3"><div class="delete-wpr"><select id= "item-name'+rowIndex+'" onchange="getUnitPrice(this.id)">'+select+'</select><a class="delete" href="javascript:;" title="Remove row">X</a></div></td><td><input id="quantity'+rowIndex+'" class="qty text-center" value="0" type="number" onblur="checkProductShippedTo(this.id)"><span id="error_msg'+rowIndex+'" style="color: red;"></span></td><td><input id="unit-cost'+rowIndex+'" class="cost text-center" value="0" type="number"></td><input type="hidden" id="qty_value'+rowIndex+'"><td colspan="2"><span class="price">0</span></td></tr>');
        if ($(".delete").length > 0) $(".delete").show();
        bind();

    });

    bind();

    $(".delete").live('click', function() {


        $(this).parents('.item-row').remove();
        update_total();
        var tablebody  = document.getElementById("item-detail");
        var rows = tablebody.querySelectorAll("tr");
        for(var i=0;i<rows.length;i++){
                var col = rows[i].querySelector("td");
                slno = i;
                slno++;
                col.innerHTML = slno;

        }

        if ($(".delete").length < 0) $(".delete").hide();
    });

});