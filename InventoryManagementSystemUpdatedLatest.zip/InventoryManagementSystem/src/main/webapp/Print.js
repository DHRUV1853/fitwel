function  printDetails(){
    document.getElementById("footer").style.display='none';
    document.getElementById("navigation-bar").style.display='none';
    window.print();
}