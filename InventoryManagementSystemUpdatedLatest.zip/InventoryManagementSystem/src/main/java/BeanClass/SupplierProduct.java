package BeanClass;

public class SupplierProduct {
    private  String suppliername;
    private int productleft;

    public String getSuppliername() {
        return suppliername;
    }

    public void setSuppliername(String suppliername) {
        this.suppliername = suppliername;
    }

    public int getProductleft() {
        return productleft;
    }

    public void setProductleft(int productleft) {
        this.productleft = productleft;
    }
}
