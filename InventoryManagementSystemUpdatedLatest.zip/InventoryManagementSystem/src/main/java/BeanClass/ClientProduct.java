package BeanClass;


	public class ClientProduct{
		private String customername;
		private int product_req;
		
		public String getCustomername() {
			return customername;
		}
		public void setCustomername(String customername) {
			this.customername = customername;
		}
		public int getProduct_req() {
			return product_req;
		}
		public void setProduct_req(int product_req) {
			this.product_req = product_req;
		}
	}

