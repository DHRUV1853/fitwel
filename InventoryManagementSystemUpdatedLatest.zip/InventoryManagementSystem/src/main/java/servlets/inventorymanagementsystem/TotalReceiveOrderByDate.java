package servlets.inventorymanagementsystem;
import BeanClass.*;
import DAO.*;
import org.json.simple.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.util.*;

@WebServlet(name = "TotalReceiveOrderByDate", value = "/TotalReceiveOrderByDate")
public class TotalReceiveOrderByDate extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customername = request.getParameter("customername");
        String fromdate = request.getParameter("fromdate");
        String todate = request.getParameter("todate");

        PrintWriter out = response.getWriter();

        if(customername.isEmpty() || fromdate.isEmpty() || todate.isEmpty()){
            out.println("<script type = \"text/javascript\">");
            out.println("alert('Please select date or customer name');");
            out.println("</script>");
        }

        else{
            Dao d = new Dao();
            List<OrderBean> list = d.getTotalReceiveOrderByDate(customername, fromdate , todate);


            JSONArray json = new JSONArray();

            for(OrderBean ot : list) {
                JSONObject jsonobj = new JSONObject();
                jsonobj.put("productname",ot.getProductname());

                for(ClientProduct cp: ot.getProductreq()) {
                    jsonobj.put(cp.getCustomername(), cp.getProduct_req());
                }

                json.add(jsonobj);
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json.toString());
        }
    }
}
