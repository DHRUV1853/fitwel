package servlets.inventorymanagementsystem;
import BeanClass.SupplierBean;
import DAO.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import java.util.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "GetAllPurchaseBillDetail", value = "/GetAllPurchaseBillDetail")
public class GetAllPurchaseBillDetail extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        Dao d = new Dao();

        List<SupplierBean> list = d.getAllSupplierDetail();
        JSONArray jsonArray = new JSONArray();
        for (SupplierBean sb: list) {
            JSONObject obj = new JSONObject();
            obj.put("supplierid",sb.getSupplierid());
            obj.put("suppliername",sb.getSuppliername());
            obj.put("gstno",sb.getGstno());
            obj.put("invoiceno",sb.getInvoiceno());
            obj.put("hsn",sb.getHsncode());
            obj.put("purchaseorderdate",sb.getPurchaseorderdate());
            obj.put("subtotal",sb.getSubtotal());
            obj.put("quantity",sb.getQuantity());
            obj.put("cgst",sb.getCgst());
            obj.put("sgst",sb.getSgst());
            obj.put("igst",sb.getIgst());
            obj.put("packingcharges",sb.getPackingcharges());
            obj.put("compensationcess",sb.getCompensationcess());
            obj.put("tcs",sb.getTcs());

            jsonArray.add(obj);
        }
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonArray.toString());

    }
}
