package servlets.inventorymanagementsystem;

import BeanClass.*;
import java.util.*;
import DAO.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "GetAllInvoicesDetails", value = "/GetAllInvoicesDetails")
public class GetAllInvoicesDetails extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Dao d = new Dao();
//        List<OrderBean> list = d.getAllInvoiceDetails();
    }
}
