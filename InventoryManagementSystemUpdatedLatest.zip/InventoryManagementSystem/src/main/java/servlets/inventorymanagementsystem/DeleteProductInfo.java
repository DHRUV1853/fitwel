package servlets.inventorymanagementsystem;

import DAO.Dao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "DeleteProductInfo", value = "/DeleteProductInfo")
public class DeleteProductInfo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productId = request.getParameter("productid");
        Dao d = new Dao();
        int status = d.deleteProduct(productId);

        if(status > 0){
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Product deleted successfully");
        }

        else {
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Product is not deleted");
        }



    }
}
