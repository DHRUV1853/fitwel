package servlets.inventorymanagementsystem;

import org.json.simple.*;
import java.util.*;
import BeanClass.*;
import DAO.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "TotalInvoiceLists", value = "/TotalInvoiceLists")
public class TotalInvoiceLists extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Dao d = new Dao();
        List<OrderBean> list = d.getAllInvoiceDetails();

        JSONArray json = new JSONArray();
        for(OrderBean ob : list){

            JSONObject obj = new JSONObject();
            obj.put("orderid", ob.getOrderid());
            obj.put("gstno", ob.getGstno());
            obj.put("hsncode", ob.getHsncode());
            obj.put("billingaddress", ob.getBillingaddress());
            obj.put("clientname", ob.getclientName());
            obj.put("clientemail", ob.getClientEmail());
            obj.put("clientaddress", ob.getClientAddress());
            obj.put("contactno", ob.getContactnumber());
            obj.put("invoicegeneratedate", ob.getInvoicegeneratedate());
            obj.put("productname", ob.getProductname());
            obj.put("totalprice", ob.getTotalProductPrice());
            obj.put("productquantity", ob.getProductshippedto());
            obj.put("orderplaceddate",ob.getOrderPlacedDate());
            obj.put("orderplacedtime",ob.getOrderPlacedTime());
            obj.put("orderstatus",ob.getOrderStatus());
            obj.put("invoicestatus",ob.getInvoiceStatus());
            json.add(obj);

        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json.toString());
    }
}
