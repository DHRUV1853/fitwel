package servlets.inventorymanagementsystem;

import BeanClass.ClientProduct;
import BeanClass.OrderBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ConsolidateOrderByCustomerName", value = "/ConsolidateOrderByCustomerName")
public class ConsolidateOrderByCustomerName extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String customername = request.getParameter("customername");
        Dao d = new Dao();
        List<OrderBean> list = d.getAllConsolidateOrderByCustomerName(customername);
        JSONArray json = new JSONArray();

        for(OrderBean ot : list) {
            JSONObject jsonobj = new JSONObject();
            jsonobj.put("productname",ot.getProductname());


            for(ClientProduct cp: ot.getProductreq()) {
                jsonobj.put(cp.getCustomername(), cp.getProduct_req());
            }

            json.add(jsonobj);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json.toString());
    }
}
