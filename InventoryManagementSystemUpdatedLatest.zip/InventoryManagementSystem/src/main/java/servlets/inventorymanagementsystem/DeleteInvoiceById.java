package servlets.inventorymanagementsystem;

import DAO.Dao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "DeleteInvoiceById", value = "/DeleteInvoiceById")
public class DeleteInvoiceById extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("rowindex");
        Dao d = new Dao();
        int status =0;
        status = d.deleteInvoiceById(id);
        if(status > 0){
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Invoice deleted successfully");
        }
        else{
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Invoice is not deleted");
        }
    }
}
