package servlets.inventorymanagementsystem;
import DAO.*;
import BeanClass.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.Properties;
//import javax.mail.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/InvoiceStatus")
public class InvoiceStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//	private void sendEmail(String from, String pass,String to, String login_username, String login_password,PrintWriter out)
//	  {
//	  	Properties props = System.getProperties();
//	  	props.put("mail.smtp.starttls.enable","true"); 
//	  	props.put("mail.smtp.user",from); 
//	  	props.put("mail.smtp.host", "smtp.gmail.com");  
//	  	props.put("mail.smtp.auth", "true"); 
//	  	
//	  	props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory"); 
//	  	props.setProperty("mail.smtp.socketFactory.fallback", "false"); 
//	  	props.setProperty("mail.smtp.port", "465"); 
//	  	props.setProperty("mail.smtp.socketFactory.port", "465"); 
//	  	
//
//	  	
//	  	Session ss = Session.getInstance(props,new Authenticator() {
//	  		@Override
//	  		protected PasswordAuthentication getPasswordAuthentication() {
//	  			return new PasswordAuthentication(from,pass);
//	  			
//	  			
//	  		}
//	  	});
//	  	
//	  	ss.setDebug(true);
//	  	MimeMessage m = new MimeMessage(ss);
//	  	try {
//	  		m.setFrom(new InternetAddress(from));
//	  		m.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
//	  		m.setSubject("Registration Completed Successfully");
//	  		String msg = "Your registration completed successfully and username is "+login_username+" and password is "+login_password;
//	  		m.setText(msg);
//	  		
//	  		Transport.send(m);
//	  		
//	  		System.out.println("Mail sent Successfully....");
//
//	  		
//	  	}catch(Exception ex) {ex.printStackTrace();}
//	  	
//	  }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String invoicestatus = request.getParameter("invoiceStatus");
		String clientname = request.getParameter("customername");
		String hsncode = request.getParameter("hsncode");
		String billingaddress = request.getParameter("billingaddress");
		String itemdetail = request.getParameter("itemdetail");
		String billno = request.getParameter("billno");
		String invoicegeneratedate = request.getParameter("invoicegeneratedate");
		String gstno = request.getParameter("gstno");
		Dao d = new Dao();


		int check = d.checkInvoiceNo(billno);

		if(check > 0){
			response.setContentType("text/plain");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write("Invoice number is already added");
		}

		else {


			JSONParser parser = new JSONParser();
			int status = 0;

			try {
				JSONArray jsonarr = (JSONArray) parser.parse(itemdetail);
				for (int i = 0; i < jsonarr.size(); i++) {
					JSONObject jsonObj = (JSONObject) jsonarr.get(i);
					status = d.updateInvoiceStatusByClientName(invoicestatus, clientname, (String) jsonObj.get("productshippedto"), (String) jsonObj.get("productname"), hsncode, billingaddress, billno, invoicegeneratedate, gstno);
				}

			} catch (ParseException e) {
				e.printStackTrace();
			}

			if (status > 0) {
				response.setContentType("text/plain");
				response.setCharacterEncoding("UTF-8");
				response.getWriter().write("Invoice updated successfully");
			}


//
//
//		if(invoicestatus.isEmpty() || invoicestatus==null) {
//			response.setCharacterEncoding("UTF-8");
//			response.setContentType("text/plain");
//			response.getWriter().write("Invoice Status should not be empty");
//		}
//		else if(clientname.isEmpty() || clientname==null) {
//			response.setCharacterEncoding("UTF-8");
//			response.setContentType("text/plain");
//			response.getWriter().write("Client Name should not be empty");
//		}
//
//
//
//				Dao d = new Dao();
//				int status =0;
//				if(d.checkProductRequiredStatus(productshippedto,clientname, productname, productsize)){
//					status =  d.updateInvoiceStatusByClientName(invoicestatus, clientname, productshippedto,productname, productsize);
//					if(status >0) {
//
//						response.setCharacterEncoding("UTF-8");
//						response.setContentType("text/plain");
//						response.getWriter().write("Invoice Status is updated ");
//
//					}
//				}
//
//				else{
//					response.setCharacterEncoding("UTF-8");
//					response.setContentType("text/plain");
//					response.getWriter().write("Quantity is more than client's requirement");
//				}
//
//
//
//
//
//
//		}
		}
	}
}

