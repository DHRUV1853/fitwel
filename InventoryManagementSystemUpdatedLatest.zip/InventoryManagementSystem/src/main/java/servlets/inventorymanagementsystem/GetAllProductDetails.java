package servlets.inventorymanagementsystem;

import BeanClass.ProductDetailBean;
import BeanClass.SupplierBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "GetAllProductDetails", value = "/GetAllProductDetails")
public class GetAllProductDetails extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Dao d = new Dao();
        List<ProductDetailBean> list = d.getAllProductName();
        JSONArray jsonArray = new JSONArray();
            for (ProductDetailBean pd: list) {
                JSONObject obj = new JSONObject();
                obj.put("productname",pd.getProductname());
                jsonArray.add(obj);
            }
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonArray.toString());
    }
}
