package servlets.inventorymanagementsystem;

import BeanClass.OrderBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "TotalInvoiceListsByDate", value = "/TotalInvoiceListsByDate")
public class TotalInvoiceListsByDate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fromdate = request.getParameter("fromdate");
        String todate = request.getParameter("todate");
        Dao d = new Dao();
        List<OrderBean> list = d.getAllInvoiceDetailsByDate(fromdate,todate);

        JSONArray json = new JSONArray();
        for(OrderBean ob : list){

            JSONObject obj = new JSONObject();
            obj.put("orderid", ob.getOrderid());
            obj.put("gstno", ob.getGstno());
            obj.put("hsncode", ob.getHsncode());
            obj.put("billingaddress", ob.getBillingaddress());
            obj.put("clientname", ob.getclientName());
            obj.put("clientemail", ob.getClientEmail());
            obj.put("clientaddress", ob.getClientAddress());
            obj.put("contactno", ob.getContactnumber());
            obj.put("invoicegeneratedate", ob.getInvoicegeneratedate());
            obj.put("productname", ob.getProductname());
            obj.put("totalprice", ob.getTotalProductPrice());
            obj.put("productquantity", ob.getProductshippedto());
            obj.put("orderplaceddate",ob.getOrderPlacedDate());
            obj.put("orderplacedtime",ob.getOrderPlacedTime());
            obj.put("orderstatus",ob.getOrderStatus());
            obj.put("invoicestatus",ob.getInvoiceStatus());
            json.add(obj);

        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json.toString());
    }
}
