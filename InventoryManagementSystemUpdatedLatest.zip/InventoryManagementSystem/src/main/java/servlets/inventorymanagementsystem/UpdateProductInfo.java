package servlets.inventorymanagementsystem;

import DAO.Dao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UpdateProductInfo", value = "/UpdateProductInfo")
public class UpdateProductInfo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productid = request.getParameter("productid");
        String productName = request.getParameter("productname");
        String productSize = request.getParameter("productsize");
        String productUnitPrice = request.getParameter("productunitprice");
        String productType = request.getParameter("producttype");
        Dao d = new Dao();
                int status = d.updateProductInfo(productid,productName,productSize,productUnitPrice,productType);
                if(status > 0){
                    response.setContentType("text/plain");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write("Product detail updated successfully");
                }
            }

}
