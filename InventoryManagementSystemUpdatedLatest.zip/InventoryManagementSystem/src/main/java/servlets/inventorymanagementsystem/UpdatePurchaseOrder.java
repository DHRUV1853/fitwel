package servlets.inventorymanagementsystem;

import BeanClass.SupplierBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UpdatePurchaseOrder", value = "/UpdatePurchaseOrder")
public class UpdatePurchaseOrder extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemdetails = request.getParameter("purchaseorderdetails");
        String tcspercentage = request.getParameter("tcspercentage");
        String compensationcesspercentage = request.getParameter("compensationcesspercentage");
        String packingchargepercentage = request.getParameter("packingchargepercentage");
        String suppliername = request.getParameter("suppliername");

        Dao d = new Dao();
        int status = 0;
        SupplierBean sb = new SupplierBean();

        sb.setSuppliername(suppliername);
        sb.setTcs(tcspercentage);
        sb.setCompensationcess(compensationcesspercentage);
        sb.setPackingcharges(packingchargepercentage);

        if(itemdetails.isEmpty() || itemdetails == null || tcspercentage.isEmpty() || tcspercentage == null || packingchargepercentage.isEmpty() || packingchargepercentage == null || compensationcesspercentage.isEmpty() || compensationcesspercentage == null || suppliername.isEmpty() || suppliername == null){
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Fields cannot be empty!!");
        }
        else{

            JSONParser parser = new JSONParser();
            try {
                JSONArray jsonarr = (JSONArray) parser.parse(itemdetails);
                for (int i = 0; i < jsonarr.size(); i++)
                {
                    JSONObject jsonObj = (JSONObject) jsonarr.get(i);

                    status = d.updatePurchaseOrder((String) jsonObj.get("productdetail"), (String) jsonObj.get("quantity"),sb);

                }
            } catch (ParseException e) {e.printStackTrace();}

            if(status > 0){
                response.setContentType("text/plain");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("Purchase bill invoice updated successfully");
            }

        }
    }
}
