package servlets.inventorymanagementsystem;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import DAO.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@WebServlet(name = "GetUnitPrice", value = "/GetUnitPrice")
public class GetUnitPrice extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customername = request.getParameter("customername");
        String productname = request.getParameter("productname");

        Dao d = new Dao();

        long unitprice = d.getUnitPrice(customername, productname);
        long product_req = d.getProductRequired(customername, productname);

        JSONObject json = new JSONObject();

        json.put("unitprice",unitprice);
        json.put("productrequired",product_req);


        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        response.getWriter().write(json.toString());

    }
}
