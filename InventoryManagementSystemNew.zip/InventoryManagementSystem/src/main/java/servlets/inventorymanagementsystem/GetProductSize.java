package servlets.inventorymanagementsystem;

import BeanClass.*;
import DAO.*;
import org.json.simple.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.*;

@WebServlet(name = "GetProductSize", value = "/GetProductSize")
public class GetProductSize extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productname = request.getParameter("productname");
        String customername = request.getParameter("customername");
        Dao d = new Dao();
        List<OrderBean> list = d.getAllProductSizeByCustomernameAndProductname(customername, productname);

        JSONArray json = new JSONArray();
        for(OrderBean ob : list){

            JSONObject obj = new JSONObject();
            obj.put("productsize", ob.getProductsize());
            json.add(obj);

        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json.toString());
    }
}
