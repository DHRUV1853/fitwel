package BeanClass;

public class SupplierBean{
    String suppliername;
    String supplieremail;
    String supplieraddress;
    String invoiceno;
    String purchaseorderdate;
    String packingcharges;
    String compensationcess;

    public String getPackingcharges() {
        return packingcharges;
    }

    public void setPackingcharges(String packingcharges) {
        this.packingcharges = packingcharges;
    }

    public String getCompensationcess() {
        return compensationcess;
    }

    public void setCompensationcess(String compensationcess) {
        this.compensationcess = compensationcess;
    }

    public String getTcs() {
        return tcs;
    }

    public void setTcs(String tcs) {
        this.tcs = tcs;
    }

    String tcs;

    public String getCgst() {
        return cgst;
    }

    public void setCgst(String cgst) {
        this.cgst = cgst;
    }

    public String getSgst() {
        return sgst;
    }

    public void setSgst(String sgst) {
        this.sgst = sgst;
    }

    public String getIgst() {
        return igst;
    }

    public void setIgst(String igst) {
        this.igst = igst;
    }

    String gstno;
    String hsncode;
    String totalprice,cgst,sgst,igst;

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    String quantity;

    public String getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(String subtotal) {
        this.subtotal = subtotal;
    }

    String subtotal;

    public String getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(String totalprice) {
        this.totalprice = totalprice;
    }

    public String getHsncode() {
        return hsncode;
    }

    public void setHsncode(String hsncode) {
        this.hsncode = hsncode;
    }

    public String getSuppliername() {
        return suppliername;
    }

    public void setSuppliername(String suppliername) {
        this.suppliername = suppliername;
    }

    public String getSupplieremail() {
        return supplieremail;
    }

    public void setSupplieremail(String supplieremail) {
        this.supplieremail = supplieremail;
    }

    public String getSupplieraddress() {
        return supplieraddress;
    }

    public void setSupplieraddress(String supplieraddress) {
        this.supplieraddress = supplieraddress;
    }

    public String getInvoiceno() {
        return invoiceno;
    }

    public void setInvoiceno(String invoiceno) {
        this.invoiceno = invoiceno;
    }

    public String getPurchaseorderdate() {
        return purchaseorderdate;
    }

    public void setPurchaseorderdate(String purchaseorderdate) {
        this.purchaseorderdate = purchaseorderdate;
    }

    public String getGstno() {
        return gstno;
    }

    public void setGstno(String gstno) {
        this.gstno = gstno;
    }
}
