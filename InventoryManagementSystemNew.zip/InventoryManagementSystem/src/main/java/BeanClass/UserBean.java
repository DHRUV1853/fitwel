package BeanClass;
public class UserBean {
String firstname,lastname,email,phone,address,country,state,zipcode,postion,username,password;
int id;
public void setId(int id) {
	this.id = id;
}
public int getId() {
	return id;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getFirstname() {
	return firstname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getLastname() {
	return lastname;
}
public void setEmail(String email) {
	this.email = email;
}
public String getEmail() {
	return email;
}
public void setAddress(String addrress) {
	this.address = addrress;
}
public String getAddress() {
	return address;
}
//public void setCountry(String country) {
//	this.country =  country;
//}
//public String getCountry() {
//	return country;
//}
//public void setState(String state) {
//	this.state = state;
//}
//public String getState() {
//	return state;
//}
//public void setZipcode(String zipcode) {
//	this.zipcode = zipcode;
//}
//public String getZipcode() {
//	return zipcode;
//}
public void setPosition(String position) {
	this.postion = position;
}
public String getPosition() {
	return postion;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getPhone() {
	return phone;
}
public void setUsername(String username) {
	this.username = username;
}
public String getUsername() {
	return username;
}
public void setPassword(String password) {
	this.password = password;
}
public String getPassword() {
	return password;
}
}
